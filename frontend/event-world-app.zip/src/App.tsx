import React from 'react';
import './App.css';
import { Login } from './pages/login/login'

function App() {
  return (
    <div className='rootStyle'>
      <Login />
    </div>
  );
}

export default App;
